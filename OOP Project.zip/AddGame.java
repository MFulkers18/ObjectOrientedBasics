package com.company;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class AddGame {
    public static void addGame(String movesPlayed, String outcome,String source,String outputFile){
        try{
            BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile,true));
            writer.newLine();
            writer.write(String.format("%s:%s:%s",movesPlayed,outcome,source));
            writer.flush();
            writer.close();
        }
        catch(IOException ioException){
            System.out.println(String.format("Could not find \"%s\": %s",
                    outputFile,ioException.getMessage()));
        }
        Game game = new Game(movesPlayed,outcome,source);
        GameDatabase.getInstance().addType(game);
    }
}
