package com.company;

import java.util.ArrayList;
import java.util.List;

public class OpeningDatabase implements SearchableDatabase<Opening> {
    private ArrayList<Opening> openings = new ArrayList<>();
    private static OpeningDatabase openingDatabase = null;

    private OpeningDatabase(){}

    public static OpeningDatabase getInstance(){
        if(openingDatabase == null){
            openingDatabase = new OpeningDatabase();
        }
        return openingDatabase;
    }

    @Override
    public List<Opening> getDatabase() {
        return openings;
    }

    @Override
    public void addType(Opening opening) {openings.add(opening);}

    @Override
    public List<Opening> search(String openingName, String openingMoves, String source) {
        return null;
    }
}
