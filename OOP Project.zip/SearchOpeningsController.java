package com.company;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class SearchOpeningsController extends Controller{

    @FXML TextField openingNameField;

    @FXML TextField formingMovesField;

    protected static String matchingOpeningResults = "";


    @FXML protected void searchByMovesClicked(){
        matchingOpeningResults = ConductOpeningSearch.getMatchingOpening("formingMoves",
                formingMovesField.getText(),
                OpeningDatabase.getInstance().getDatabase());
        super.controllerDelegate.delegateAction("SearchOpeningsResultsGUI.fxml");
    }

    @FXML public void cancelButtonClicked(){
        super.controllerDelegate.delegateAction("MainScreenGUI.fxml");
    }


    @Override
    protected void controllerAction() {
        matchingOpeningResults = ConductOpeningSearch.getMatchingOpening("openingName",
                openingNameField.getText(),
                OpeningDatabase.getInstance().getDatabase());
        super.controllerDelegate.delegateAction("SearchOpeningsResultsGUI.fxml");
    }
}
