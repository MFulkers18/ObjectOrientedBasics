package com.company;

import java.util.List;

public class ConductOpeningSearch {
    private static String organizeOpeningInfo(Opening opening){
        return String.format("Opening Name: %s, Forming Moves: %s, Best Reply: %s, History: %s",
                opening.getName(), opening.getFormingMoves(), opening.getBestReply(), opening.getHistory());
    }


    public static String getMatchingOpening(String searchType, String searchString, List<Opening> openings){
        switch (searchType){
            case "openingName":
                for(Opening opening:openings){
                    if(opening.getName().toLowerCase().contains(searchString.toLowerCase())){
                        return organizeOpeningInfo(opening);
                    }
                }

            case "formingMoves":
                for(Opening opening:openings){
                    if(opening.getFormingMoves().startsWith(searchString)){
                        return organizeOpeningInfo(opening);
                    }
                }
        }
        return String.format("No search results found for \"%s\".", searchString);
    }
}
