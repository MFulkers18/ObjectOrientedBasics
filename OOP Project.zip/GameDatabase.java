package com.company;

import java.util.ArrayList;
import java.util.List;

public class GameDatabase implements SearchableDatabase<Game> {
    private ArrayList<Game> games = new ArrayList<>();
    private static GameDatabase gameDatabase = null;

    private GameDatabase(){}

    public static GameDatabase getInstance(){
        if(gameDatabase == null){
            gameDatabase = new GameDatabase();
        }
        return gameDatabase;
    }

    @Override
    public List<Game> getDatabase() {
        return games;
    }

    @Override
    public void addType(Game game) {games.add(game);}

    @Override
    public List<Game> search(String openingName, String openingMoves, String source) {
        return null;
    }
}
