package com.company;

import java.util.List;

public interface SearchableDatabase<Type> {
    List<Type> getDatabase();
    void addType(Type type);
    List<Type> search(String openingName, String openingMoves, String source);
}
