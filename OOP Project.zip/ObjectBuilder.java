package com.company;

public class ObjectBuilder {
    public static Game gameBuilder(String gameFromInput){
        String[] gameTokens = gameFromInput.split(":");
        Game game = new Game(gameTokens[0],gameTokens[1],gameTokens[2]);
        return game;
    }

    public static Opening openingBuilder(String openingFromInput){
        String[] openingTokens = openingFromInput.split(":");
        Opening opening = new Opening(openingTokens[0],openingTokens[1],openingTokens[2],openingTokens[3]);
        return opening;
    }
}

