package com.company;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class DatabasePopulator {
    public static void populateDatabase(String databaseType, String inputFile){
        try{
            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            String lineFromFile = reader.readLine();
            while(lineFromFile != null){
                switch(databaseType){
                    case "game" :
                        GameDatabase.getInstance().addType(ObjectBuilder.gameBuilder(lineFromFile));
                        break;

                    case "opening":
                        OpeningDatabase.getInstance().addType(ObjectBuilder.openingBuilder(lineFromFile));
                        break;
                }
                lineFromFile = reader.readLine();
            }
        }
        catch(FileNotFoundException fileNotFoundException){
            System.out.println(String.format("Could not file file \"%s\": %s",
                    inputFile,fileNotFoundException.getMessage()));
        }
        catch(IOException ioException){
            System.out.println("Could not read line from file:"+ioException.getMessage());
        }
    }
}