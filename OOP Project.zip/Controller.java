package com.company;

import javafx.fxml.FXML;

abstract class Controller {
    protected interface ControllerDelegate{
        void delegateAction(String fxmlName);
    }

    protected ControllerDelegate controllerDelegate = null;

   @FXML protected void controllerAction(){}
}
