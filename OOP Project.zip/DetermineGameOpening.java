package com.company;

import java.util.List;

public class DetermineGameOpening {
    private static void determineOpening(Game game) {
        for (Opening opening : OpeningDatabase.getInstance().getDatabase()) {
            if (game.getMovesPlayed().startsWith(opening.getFormingMoves())) {
                game.setOpening(opening);
            }
        }
    }

    public static void determineOpenings(List<Game> games) {
        for (Game game : games) {
            determineOpening(game);
        }
    }
}
