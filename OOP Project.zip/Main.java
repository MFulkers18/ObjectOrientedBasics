/*
/ Mike Fulkerson
/ CSC 240-S01
/ Dr. Krupp
/ Final Project: Checker Game Database with GUI
/ 29 April 2019
 */



package com.company;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application{

    @Override
    public void start(Stage primaryStage) throws Exception {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("MainScreenGUI.fxml"));
        Parent root = loader.load();

        GUIHandler guiHandler = new GUIHandler(primaryStage);
        guiHandler.setController(loader);

        primaryStage.setTitle("Checker Games Database");
        primaryStage.setScene(new Scene(root,800,400));
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
