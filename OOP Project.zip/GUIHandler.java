package com.company;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.stage.Stage;

public class GUIHandler implements Controller.ControllerDelegate {
   private Stage primaryStage;


   public GUIHandler(Stage primaryStage){
      this.primaryStage = primaryStage;
   }


    protected void setController(FXMLLoader loader){
       Controller controller = loader.getController();
       controller.controllerDelegate = this;
    }


    private void changeControllerDelegate(String fxmlName)throws Exception{
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlName));
        Parent root = loader.load();
        primaryStage.getScene().setRoot(root);
        setController(loader);
    }


    @Override
    public void delegateAction(String fxmlName) {
        try {
            this.changeControllerDelegate(fxmlName);
        }
        catch (Exception exception) {
            System.out.println("Exception error: "+exception.getMessage());
        }
    }
}
