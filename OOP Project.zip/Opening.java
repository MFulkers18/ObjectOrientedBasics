package com.company;

public class Opening {
    private String name;
    private String formingMoves;
    private String bestReply;
    private String history;

    public Opening(String name, String formingMoves, String bestReply, String history){
        this.name = name;
        this.formingMoves = formingMoves;
        this.bestReply = bestReply;
        this.history = history;
    }

    public String getName(){return this.name;}

    public String getFormingMoves(){return this.formingMoves;}

    public String getBestReply(){return this.bestReply;}

    public String getHistory(){return this.history;}
}
