package com.company;

import java.util.List;

public class OrganizeSearchResults {
    public static String showOrganizedResults(String openingName, String openingMoves, String playerName){
        List<Game> searchResults = ConductGameSearch.getSearchResults(openingName,openingMoves,playerName);
        StringBuilder resultsDescription = new StringBuilder();

        try {
            if (searchResults.isEmpty()) {
                return "No matching results were found.";
            }
            else{
                for(Game game:searchResults){
                    String gameDescription = String.format("Opening Name: %s, Opening Moves: %s," +
                                    " Moves Played:%s, Game Result: %s, Players / Source: %s\n\n",
                            game.getOpening().getName(),game.getOpening().getFormingMoves(),
                            game.getMovesPlayed(),game.getOutcome(),game.getSource());
                    resultsDescription.append(gameDescription);
                }
                return resultsDescription.toString();
            }
        }
        catch (NullPointerException nullPointerException){
            return "No matching results were found.";
        }


    }
}
