package com.company;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;


public class SearchGamesController extends Controller{

    @FXML private TextField openingNameField;

    @FXML private TextField openingMovesField;

    @FXML private TextField playerNameField;

    protected static String searchResults = "";


    @FXML protected void cancelButtonClicked(){
        super.controllerDelegate.delegateAction("MainScreenGUI.fxml");
    }

    @Override
    protected void controllerAction() {
        String openingName = openingNameField.getText();
        String openingMoves = openingMovesField.getText();
        String playerName = playerNameField.getText();

        searchResults = OrganizeSearchResults.showOrganizedResults(openingName,openingMoves,playerName);

        super.controllerDelegate.delegateAction("SearchGamesResultsGUI.fxml");
    }

}



