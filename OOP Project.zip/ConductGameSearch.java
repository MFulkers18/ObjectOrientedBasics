package com.company;


import java.util.ArrayList;
import java.util.List;

public class ConductGameSearch {
    private static List<Game> getMatchingGames(List<Game> gamesToSearch,
                                               String gameProperty, String searchString) {

        List<Game> matchingOpeningNames = new ArrayList<>();
        List<Game> matchingOpeningMoves = new ArrayList<>();
        List<Game> matchingPlayerNames = new ArrayList<>();

        if (! searchString.equals("")) {
            switch (gameProperty) {
                case "openingName":
                    for (Game game : gamesToSearch) {
                        if (game.getOpening().getName().toLowerCase().contains(searchString.toLowerCase())) {
                            matchingOpeningNames.add(game);
                        }
                    }
                    return matchingOpeningNames;

                case "openingMoves":
                    for (Game game : gamesToSearch) {
                        if (game.getOpening().getFormingMoves().startsWith(searchString)) {
                            matchingOpeningMoves.add(game);
                        }
                    }
                    return matchingOpeningMoves;


                case "playerName":
                    for (Game game : gamesToSearch) {
                        if (game.getSource().toLowerCase().contains(searchString.toLowerCase())) {
                            matchingPlayerNames.add(game);
                        }
                    }
                    return matchingPlayerNames;

            }
        }
        return null;
    }

    private static List<Game> compareResultsLists(List<Game> mainCompareList, List<Game> secondaryCompareList, List<Game> thirdCompareList){
        List<Game> checkList = new ArrayList<>();

        if(mainCompareList != null){
            if((secondaryCompareList != null) && (thirdCompareList != null)){
                for(Game game:mainCompareList){
                    if(secondaryCompareList.contains(game) && thirdCompareList.contains(game)){
                        checkList.add(game);
                    }
                }
                return checkList;
            }
            else if((secondaryCompareList != null) || (thirdCompareList != null)){
                for(Game game: mainCompareList){
                    if((secondaryCompareList != null && secondaryCompareList.contains(game))
                            || (thirdCompareList != null && thirdCompareList.contains(game))){
                        checkList.add(game);
                    }
                }
                return checkList;
            }
            return mainCompareList;
        }
        else if(secondaryCompareList != null){
            if(thirdCompareList != null){
                for(Game game:secondaryCompareList){
                    if(thirdCompareList.contains(game)){
                        checkList.add(game);
                    }
                }
                return checkList;
            }
            return secondaryCompareList;
        }
        else if(thirdCompareList != null){
            return thirdCompareList;
        }
        return null;
    }


    public static List<Game> getSearchResults(String openingName, String openingMoves, String playerName){
        List<Game> gamesToSearch = GameDatabase.getInstance().getDatabase();
        List<Game> matchingOpeningNames = getMatchingGames(gamesToSearch,"openingName",openingName);
        List<Game> matchingOpeningMoves = getMatchingGames(gamesToSearch,"openingMoves",openingMoves);
        List<Game> matchingPlayerNames = getMatchingGames(gamesToSearch,"playerName",playerName);

        return compareResultsLists(matchingOpeningNames,matchingOpeningMoves,matchingPlayerNames);
    }
}
