package com.company;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;


public class AddGameController extends Controller {
    @FXML TextField movesPlayedField;

    @FXML TextField gameResultField;

    @FXML TextField gameSourceField;

    @FXML protected  void cancelButtonClicked(){
        super.controllerDelegate.delegateAction("MainScreenGUI.fxml");
    }


    @Override
    protected void controllerAction() {
        String movesPlayed = movesPlayedField.getText();
        String gameResult= gameResultField.getText();
        String gameSource = gameSourceField.getText();

        AddGame.addGame(movesPlayed,gameResult,gameSource,"CheckerGames.txt");
        super.controllerDelegate.delegateAction("MainScreenGUI.fxml");
    }
}
