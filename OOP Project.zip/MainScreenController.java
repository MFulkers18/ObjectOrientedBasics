package com.company;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

public class MainScreenController extends Controller implements Initializable {

    @FXML protected void addGameClicked(){
        super.controllerDelegate.delegateAction("AddGameGUI.fxml");
    }


    @FXML protected void searchOpeningHistoryClicked(){
        super.controllerDelegate.delegateAction("SearchOpeningsGUI.fxml");

    }


    @Override
    protected void controllerAction() {
        super.controllerDelegate.delegateAction("SearchGamesGUI.fxml");
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        GameDatabase.getInstance().getDatabase().clear();

        DatabasePopulator.populateDatabase("opening","CheckerOpenings.txt");
        DatabasePopulator.populateDatabase("game","CheckerGames.txt");

        DetermineGameOpening.determineOpenings(GameDatabase.getInstance().getDatabase());
    }
}
