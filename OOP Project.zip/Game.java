package com.company;

public class Game {
    private String movesPlayed;
    private String outcome;
    private String source;
    private Opening opening;

    public Game(String movesPlayed, String outcome, String source){
        this.movesPlayed = movesPlayed;
        this.outcome = outcome;
        this.source = source;
    }

    public String getMovesPlayed(){return this.movesPlayed;}

    public String getOutcome(){return this.outcome;}

    public String getSource(){return this.source;}

    public void setOpening(Opening opening){this.opening = opening;}

    public Opening getOpening(){return this.opening;}
}
